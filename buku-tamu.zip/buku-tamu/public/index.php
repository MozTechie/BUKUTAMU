<?php
require_once __DIR__ . "/../config/database.php";

require_once __DIR__ . "/../app/controllers/GuestController.php";


$database = new Database();
$db = $database->getConnection();
$controller = new GuestController($db);

$action = $_GET['action'] ?? 'index';
if (method_exists($controller, $action)) {
    $controller->$action();
} else {
    echo "Halaman tidak ditemukan!";
}
?>
