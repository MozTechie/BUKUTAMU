<?php
class Guest {
    private $conn;
    private $table = "guests";

    public $id;
    public $name;
    public $contact;
    public $visit_reason;
    public $visit_date;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllGuests() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY visit_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function createGuest() {
        $query = "INSERT INTO " . $this->table . " SET name=:name, contact=:contact, visit_reason=:visit_reason, visit_date=:visit_date";
        $stmt = $this->conn->prepare($query);

        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->contact = htmlspecialchars(strip_tags($this->contact));
        $this->visit_reason = htmlspecialchars(strip_tags($this->visit_reason));
        $this->visit_date = htmlspecialchars(strip_tags($this->visit_date));

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":contact", $this->contact);
        $stmt->bindParam(":visit_reason", $this->visit_reason);
        $stmt->bindParam(":visit_date", $this->visit_date);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>
