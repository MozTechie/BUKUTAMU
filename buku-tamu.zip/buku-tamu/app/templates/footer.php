</div> <!-- End of container -->
    <footer class="bg-light text-center py-3 mt-4">
        <p>&copy; 2024 Buku Tamu Digital</p>
    </footer>
    <!-- Link Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>

