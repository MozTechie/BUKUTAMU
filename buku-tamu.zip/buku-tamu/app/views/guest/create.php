<?php include __DIR__ . "/../../templates/header.php"; ?>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="col-md-6">
        <h2 class="text-center mb-4">Tambah Tamu</h2>
        <form action="/buku-tamu/public/index.php?controller=guest&action=store" method="POST" class="needs-validation" novalidate>
            <div class="form-row mb-3">
                <!-- Kolom Nama -->
                <div class="form-group col-md-12">
                    <label for="name" class="h6">Full Name</label>
                    <input type="text" class="form-control form-control-sm" id="name" name="name" placeholder="Full Name" required>
                    <div class="invalid-feedback">
                        Nama tamu diperlukan.
                    </div>
                </div>
            </div>

            <div class="form-row mb-3">
                <!-- Kolom Kontak -->
                <div class="form-group col-md-12">
                    <label for="contact" class="h6">Phone</label>
                    <input type="text" class="form-control form-control-sm" id="contact" name="contact" placeholder="Phone" required>
                    <div class="invalid-feedback">
                        Kontak tamu diperlukan.
                    </div>
                </div>
            </div>

            <div class="form-row mb-3">
                <!-- Kolom Alasan Kunjungan -->
                <div class="form-group col-md-12">
                    <label for="visit_reason" class="h6">Your Message</label>
                    <textarea class="form-control form-control-sm" id="visit_reason" name="visit_reason" rows="4" placeholder="Alasan kunjungan" required></textarea>
                    <div class="invalid-feedback">
                        Alasan kunjungan diperlukan.
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-sm">SEND</button>
        </form>
    </div>
</div>

<script>
    // Script untuk validasi form
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
</script>

<?php include __DIR__ . "/../../templates/footer.php"; ?>
