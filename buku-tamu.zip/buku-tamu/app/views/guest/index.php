<?php include __DIR__ . "/../../templates/header.php"; ?>

<div class="d-flex justify-content-center align-items-center mb-3">
    <h2>Daftar Tamu</h2>
</div>

<?php if (!empty($guests)) { ?>
    
        <div class="table-responsive">
        <table class="table table-bordered table-striped" style="width: 80%; margin-left: auto; margin-right: auto;">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Kontak</th>
                    <th>Alasan Kunjungan</th>
                    <th>Tanggal Kunjungan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($guests as $guest) {
                    // Memotong teks Alasan Kunjungan agar tidak terlalu panjang
                    $visit_reason = (strlen($guest['visit_reason']) > 50) ? substr($guest['visit_reason'], 0, 50) . '...' : $guest['visit_reason'];
                    echo "<tr>
                            <td>{$no}</td>
                            <td>" . htmlspecialchars($guest['name']) . "</td>
                            <td>" . htmlspecialchars($guest['contact']) . "</td>
                            <td>" . htmlspecialchars($visit_reason) . "</td>
                            <td>" . htmlspecialchars($guest['visit_date']) . "</td>
                          </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
        
    </div>
<?php } else { ?>
    <p class="text-center">Belum ada data tamu.</p>
<?php } ?>

<?php include __DIR__ . "/../../templates/footer.php"; ?>
