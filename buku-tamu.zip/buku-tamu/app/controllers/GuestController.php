<?php
require_once __DIR__ . "/../models/Guest.php";

class GuestController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function index() {
        $guestModel = new Guest($this->db);
        $guests = $guestModel->getAllGuests();
        include __DIR__ . "/../views/guest/index.php";
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $guestModel = new Guest($this->db);
            $guestModel->name = $_POST['name'];
            $guestModel->contact = $_POST['contact'];
            $guestModel->visit_reason = $_POST['visit_reason'];
            $guestModel->visit_date = $_POST['visit_date'];

            if ($guestModel->createGuest()) {
                header("Location: /buku-tamu/public/index.php");
                exit;
            }
        }
        include __DIR__ . "/../views/guest/create.php";
    }

    public function store()
{
    // Ambil data dari form
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $visit_reason = $_POST['visit_reason'];
    $visit_date = date('Y-m-d H:i:s'); // Atau bisa diambil dari form jika ingin

    // Simpan data tamu ke database
    $query = "INSERT INTO guests (name, contact, visit_reason, visit_date) 
              VALUES ('$name', '$contact', '$visit_reason', '$visit_date')";
    
    // Eksekusi query
    if ($this->db->query($query)) {
        // Setelah berhasil simpan, arahkan ke halaman index
        header("Location: /buku-tamu/public/");
        exit();
    } else {
        echo "Error: " . $this->db->error;
    }
}

}
?>
